# analysis1.R
# Carry out few simple analyses

# Correlations

##################
# Regression

m <- lm(ASM_appreciation ~ LSMS + EC + SNS + QualityOfLife +
      Musician + GHQ + IRS_empathy + IRS_fantasy, data = df)
R <- summary(m)
cat("R.adj.squared =",R$adj.r.squared,"\n")  # get R squared value
print(anova(m))                # display variables
m$coefficients[2:5]     # display coefficients for the first four variables

cat("ANOVA \n")
# ANOVA (between subjects)
a1 <- aov(ASM_appreciation ~ Gender * Education, data=df)
print(summary(a1))

rm(R,m,a1)