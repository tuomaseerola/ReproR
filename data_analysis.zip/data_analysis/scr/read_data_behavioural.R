#########################
# read_data_behavioural.R
# SWEET SORROW Discrimination (study 1) data from GUI (MAX/MSP patch)
# 2014-08-27 TE
#########################

# use matlab script for this "read_jonnas_data_sorrow.m" 
# then read these from ascii_data

mood1 <- read.table('data/exported_data/mood1.txt')
mood2 <- read.table('data/exported_data/mood2.txt')


#a<-rbind(mood1,mood2)
l_pre<-c("m1_pre","m2_pre","m3_pre","m4_pre","m5_pre","m6_pre","m7_pre","m8_pre","m9_pre","m10_pre","m11_pre","m12_pre","m13_pre","m14_pre","m15_pre","m16_pre","m17_pre","m18_pre","m19_pre","m20_pre")
l_pos<-c("m1_pos","m2_pos","m3_pos","m4_pos","m5_pos","m6_pos","m7_pos","m8_pos","m9_pos","m10_pos","m11_pos","m12_pos","m13_pos","m14_pos","m15_pos","m16_pos","m17_pos","m18_pos","m19_pos","m20_pos")
rownames(mood1)<-l_pre
rownames(mood2)<-l_pos

##

felt.anxious <- read.table('data/exported_data/felt.anxious.txt')
felt.intensity <- read.table('data/exported_data/felt.intensity.txt')
felt.moved <- read.table('data/exported_data/felt.moved.txt')
felt.peaceful <- read.table('data/exported_data/felt.peaceful.txt')
felt.sad <- read.table('data/exported_data/felt.sad.txt')
liking <- read.table('data/exported_data/liking.txt')

rownames(felt.anxious)<-"felt.anxious"
rownames(felt.intensity)<-"felt.intensity"
rownames(felt.moved)<-"felt.moved"
rownames(felt.peaceful)<-"felt.peaceful"
rownames(felt.sad)<-"felt.sad"
rownames(liking)<-"liking"


perceived.negative <- read.table('data/exported_data/perceived.negative.txt')
perceived.peaceful <- read.table('data/exported_data/perceived.peaceful.txt')
perceived.positive <- read.table('data/exported_data/perceived.positive.txt')
perceived.sad <- read.table('data/exported_data/perceived.sad.txt')
perceived.scary <- read.table('data/exported_data/perceived.scary.txt')

rownames(perceived.negative)<-"perceived.negative"
rownames(perceived.peaceful)<-"perceived.peaceful"
rownames(perceived.positive)<-"perceived.positive"
rownames(perceived.sad)<-"perceived.sad"
rownames(perceived.scary)<-"perceived.scary"

face.anger <- read.table('data/exported_data/face.anger.txt')
face.fear <- read.table('data/exported_data/face.fear.txt')
face.happy <- read.table('data/exported_data/face.happy.txt')
face.neutral <- read.table('data/exported_data/face.neutral.txt')
face.sad <- read.table('data/exported_data/face.sad.txt')


#face.labels <- read.table('face_stimuli_labels.txt')
#face.labels<-c("Anger","Anger/fear","Anger/happy","Anger/neutral","Anger/sad","Fear","Fear/anger","Fear/happy","Fear/neutral","Fear/sad","Happy","Happy/anger","Happy/fear","Happy/neutral","Happy/sad","Neutral","Neutral/anger","Neutral/fear","Neutral/happy","Neutral/sad","Sad","Sad/anger","Sad/fear","Sad/happy","Sad/neutral")

face.labels_ANGER<-c("ANGER_Anger","ANGER_Anger/fear","ANGER_Anger/happy","ANGER_Anger/neutral","ANGER_Anger/sad","ANGER_Fear","ANGER_Fear/anger","ANGER_Fear/happy","ANGER_Fear/neutral","ANGER_Fear/sad","ANGER_Happy","ANGER_Happy/anger","ANGER_Happy/fear","ANGER_Happy/neutral","ANGER_Happy/sad","ANGER_Neutral","ANGER_Neutral/anger","ANGER_Neutral/fear","ANGER_Neutral/happy","ANGER_Neutral/sad","ANGER_Sad","ANGER_Sad/anger","ANGER_Sad/fear","ANGER_Sad/happy","ANGER_Sad/neutral")
face.labels_FEAR<-c("FEAR_Anger","FEAR_Anger/fear","FEAR_Anger/happy","FEAR_Anger/neutral","FEAR_Anger/sad","FEAR_Fear","FEAR_Fear/anger","FEAR_Fear/happy","FEAR_Fear/neutral","FEAR_Fear/sad","FEAR_Happy","FEAR_Happy/anger","FEAR_Happy/fear","FEAR_Happy/neutral","FEAR_Happy/sad","FEAR_Neutral","FEAR_Neutral/anger","FEAR_Neutral/fear","FEAR_Neutral/happy","FEAR_Neutral/sad","FEAR_Sad","FEAR_Sad/anger","FEAR_Sad/fear","FEAR_Sad/happy","FEAR_Sad/neutral")
face.labels_HAPPY<-c("HAPPY_Anger","HAPPY_Anger/fear","HAPPY_Anger/happy","HAPPY_Anger/neutral","HAPPY_Anger/sad","HAPPY_Fear","HAPPY_Fear/anger","HAPPY_Fear/happy","HAPPY_Fear/neutral","HAPPY_Fear/sad","HAPPY_Happy","HAPPY_Happy/anger","HAPPY_Happy/fear","HAPPY_Happy/neutral","HAPPY_Happy/sad","HAPPY_Neutral","HAPPY_Neutral/anger","HAPPY_Neutral/fear","HAPPY_Neutral/happy","HAPPY_Neutral/sad","HAPPY_Sad","HAPPY_Sad/anger","HAPPY_Sad/fear","HAPPY_Sad/happy","HAPPY_Sad/neutral")
face.labels_NEUTRAL<-c("NEUTRAL_Anger","NEUTRAL_Anger/fear","NEUTRAL_Anger/happy","NEUTRAL_Anger/neutral","NEUTRAL_Anger/sad","NEUTRAL_Fear","NEUTRAL_Fear/anger","NEUTRAL_Fear/happy","NEUTRAL_Fear/neutral","NEUTRAL_Fear/sad","NEUTRAL_Happy","NEUTRAL_Happy/anger","NEUTRAL_Happy/fear","NEUTRAL_Happy/neutral","NEUTRAL_Happy/sad","NEUTRAL_Neutral","NEUTRAL_Neutral/anger","NEUTRAL_Neutral/fear","NEUTRAL_Neutral/happy","NEUTRAL_Neutral/sad","NEUTRAL_Sad","NEUTRAL_Sad/anger","NEUTRAL_Sad/fear","NEUTRAL_Sad/happy","NEUTRAL_Sad/neutral")
face.labels_SAD<-c("SAD_Anger","SAD_Anger/fear","SAD_Anger/happy","SAD_Anger/neutral","SAD_Anger/sad","SAD_Fear","SAD_Fear/anger","SAD_Fear/happy","SAD_Fear/neutral","SAD_Fear/sad","SAD_Happy","SAD_Happy/anger","SAD_Happy/fear","SAD_Happy/neutral","SAD_Happy/sad","SAD_Neutral","SAD_Neutral/anger","SAD_Neutral/fear","SAD_Neutral/happy","SAD_Neutral/sad","SAD_Sad","SAD_Sad/anger","SAD_Sad/fear","SAD_Sad/happy","SAD_Sad/neutral")

rownames(face.anger)<-face.labels_ANGER
rownames(face.fear)<-face.labels_FEAR
rownames(face.happy)<-face.labels_HAPPY
rownames(face.neutral)<-face.labels_NEUTRAL
rownames(face.sad)<-face.labels_SAD

# TRANSPOSE

mood1 <-t(mood1)
mood2 <-t(mood2)
felt.anxious <-t(felt.anxious)
felt.intensity <-t(felt.intensity)
felt.moved <-t(felt.moved)
felt.peaceful <-t(felt.peaceful)
felt.sad <-t(felt.sad)
liking <-t(liking)
perceived.negative <-t(perceived.negative)
perceived.peaceful <-t(perceived.peaceful)
perceived.positive <-t(perceived.positive)
perceived.sad <-t(perceived.sad)
perceived.scary <-t(perceived.scary)
face.anger <-t(face.anger)
face.fear <-t(face.fear)
face.happy <-t(face.happy)
face.neutral <-t(face.neutral)
face.sad <-t(face.sad)


#ID<-list((a=seq(1,42))) #ID 
ID<-seq(1,42) #ID 
names(ID)<-"ID"

# create data frame
tmp <- data.frame(ID,mood1)
head(tmp)
B <- data.frame(ID,mood1, mood2, felt.anxious, felt.intensity, felt.moved, felt.peaceful, felt.sad, liking, perceived.negative, perceived.peaceful, perceived.positive, perceived.sad, perceived.scary, face.anger, face.fear, face.happy, face.neutral, face.sad)

rm(list=ls(pattern = "f")) 
rm(list=ls(pattern = "a")) 
rm(list=ls(pattern = "p")) 
rm(list=ls(pattern = "l")) 
rm(list=ls(pattern = "d")) 
rm(list=ls(pattern = "o")) 
rm(list=ls(pattern = "ID")) 

cat('N x Variables:')
cat(dim(B))
cat("\n")
