# table1.R

# How are the background variables in terms of Liking for Sad Music?

# First, let's do a median split of LSMS

split_LSMS<-df$LSMS>median(df$LSMS)

# Then choose your variables

sel <- c("LSMS","Age","GHQ","IRS_fantasy","IRS_empathy","IRS_concern","IRS_perspective","IRS_distress","EC","SNS","AB","ASM_avoidance","ASM_revival","ASM_amplification","ASM_autobiographical","ASM_appreciation","ASM_appreciation")

table <- matrix(0,nrow=length(sel),ncol=4) # create an empty array

for (i in 1:length(sel)) {
	table[i,]<-c(tapply(df[,sel[i]],split_LSMS,mean, na.rm=TRUE),tapply(df[,sel[i]],split_LSMS,sd, na.rm=TRUE))
}

## ADD p-values from ANOVA to the table
pval<-0
df$split_LSMS<-split_LSMS
for (i in 1:length(sel)) {
	val<-summary(aov(df[,sel[i]] ~ split_LSMS, data=df))
	p<-val[[1]]$'Pr(>F)'
	pval[i]<-p[1]
}

table<-cbind(table,as.numeric(formatC(pval,format ="f",digits=3))) # add pvalues to the table

colnames(table)<-c("Low (M)","High (M)","Low (SD)","High (SD)","Pval")
rownames(table)<-sel
print(table)
rm(table,p,pval,sel,i,split_LSMS,val) # clean memory
