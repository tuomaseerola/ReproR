# figure1.R

## THE QUANTILES NEED TO BE DEFINED FIRST (SAD MUSIC LOVERS AND HATERS)

#pdf("figures/figure1.pdf",height=4, width=4) # filename + size of the figure
##quartz("scatterplot", height=7, width=7)
g <- ggplot(df, aes(liking,felt.sad))
g + geom_point(colour="grey50", size = 4) + geom_point(aes(colour = index), size = 3) +    theme_bw() +    theme(legend.key = element_rect(colour = "white")) +    theme(legend.position = "top")
#dev.off()

