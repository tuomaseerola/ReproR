# diagnostic_plots.R

#quartz("Histograms",height=8, width=8)
par(mfrow=c(4,4))

hist(S$Age,main="")
hist(S$Education,main="")
hist(S$Employment,main="")
hist(S$PhysicalHealth,main="")
hist(S$OverallHealth,main="")
hist(S$QualityOfLife,main="")
hist(S$Musician,main="")
hist(S$IRS_empathy,main="")
hist(S$GHQ,main="")
hist(S$EC,main="")
hist(S$SNS,main="")
hist(S$AB,main="")
hist(S$LSMS,main="")
hist(S$ASM_avoidance,main="")
hist(S$ASM_appreciation,main="")
hist(S$ASM_amplification,main="")

#quartz("Correlations",height=8, width=8)

panel.cor <- function(x, y, digits=2, prefix="", cex.cor, ...)
{
    usr <- par("usr"); on.exit(par(usr))
    par(usr = c(0, 1, 0, 1))
    r <- abs(cor(x, y,use="complete.obs"))
    txt <- format(c(r, 0.123456789), digits=digits)[1]
    txt <- paste(prefix, txt, sep="")
    if(missing(cex.cor)) cex.cor <- 0.8/strwidth(txt)
    text(0.5, 0.5, txt, cex = cex.cor * r)
}

pairs(~IRS_empathy+GHQ+EC+SNS+AB+LSMS, data=S, lower.panel=panel.smooth, upper.panel=panel.cor, 
      pch=20, main="Scatterplot Matrix")

rm(panel.cor)
