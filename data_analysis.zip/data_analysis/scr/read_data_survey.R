# read_data_survey.R

v <- read.xls('data/background_questionnaire_N42.xls', sheet=1, verbose=FALSE)
cat('N x Variables:')
cat(dim(v))
