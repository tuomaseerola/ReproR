# diagnose_simple.R

## Number of participants, age range, etc. in numbers

cat("N =",nrow(S),"\n")
cat("females =",sum(S$Gender==1),"males=",sum(S$Gender==2),"\n")
cat("Age range from",min(S$Age,na.rm=T),"to",max(S$Age,na.rm=T),"\n")
cat("M = ",mean(S$Age,na.rm=T),"SD = ",sd(S$Age,na.rm=T),"\n")

tmp<-describeBy(S$Age,S$Gender,mat=TRUE,digits=2)
cat("Mean Age by Gender (female, male)\n", tmp$mean,"\n")
tmp<-describeBy(S$GHQ,S$Gender,mat=TRUE,digits=2)
cat("Mean GHQ by Gender (female, male)\n", tmp$mean,"\n")

cat("\n")
## Correlate few items
ASM<-cbind(S$ASM_avoidance,S$ASM_autobiographical,S$ASM_revival,S$ASM_appreciation,S$ASM_intersubjective,S$ASM_amplification)
colnames(ASM)<-c("avoid.","autob.","reviv.","appr.","inters.","ampl.")

cat("Correlations between the Attitudes Towards Sad Music (ASM) factors \n")

print(round(cor(ASM),3))

rm(ASM)
rm(tmp) # clean....