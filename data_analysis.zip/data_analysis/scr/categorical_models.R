# categorical_models.R

# to what extend can we predict membership into sad music lovers or haters(index)?

## DEFINE PEOPLE IN TERMS OF THEIR LIKING AND FELT SAD RATINGS (QUANTILES)

ql <- quantile(df$liking,names=FALSE) # create index for sad-lovers
ql75<-ql[4]
qf <- quantile(df$felt.sad,names=FALSE) 
qf75<-qf[4]
ql25<-ql[2]# index for sad-dislikers
qf25<-qf[3]
df$index <- "Average" # remainders

## CREATE NEW VARIABLE
df$index[which(df$liking > ql75 & df$felt.sad > qf75)]<-"Enjoy"
df$index[which(df$liking < ql25 & df$felt.sad < qf25)]<-"Dislike"
df$index<-factor(df$index)

## TEST WHICH background variables predict this index using logistic regression
logitmodel <- glm(index ~ EC + SNS + AB + LSMS + ASM_avoidance + ASM_autobiographical + ASM_revival + ASM_appreciation + ASM_intersubjective + ASM_amplification, data = df, family = "binomial")
print(summary(logitmodel))


rm(list=ls(pattern="ql*")) # cleans the R memory, just in case
rm(list=ls(pattern="qf*")) # cleans the R memory, just in case
rm(logitmodel)
