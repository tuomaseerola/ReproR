###########################################################
## contents.R
##
## SWEET SORROW
## Liking sad music discrimination study
## sub-set of the data collected in Aug-Sep 2014 (N=42)
## Purpose - to give an R analysis example
##
## Tuomas Eerola
## 
## see readme.md or readme.pdf for documentation
##
###########################################################
#
# This contents.R is the file that is always needed, it initialises the analysis,
# loads the data, munges the data, runs the analysis, produces the figures and tables, etc.
#

## INITIALISE: SET PATH, CLEAR MEMORY AND LOAD LIBRARIES
setwd('/Users/lqbn73/Documents/custom/reproducible_data_analysis/data_analysis/')  # set current path in R to the desired directory
rm(list=ls(all=TRUE))                     # cleans the R memory, just in case
source('config/libraries.R')              # loads the extra R libraries needed

## READ DATA (Exp. 1 survey)
source('scr/read_data_survey.R')         # OUTPUT IS IN VARIABLE v
source('scr/read_data_behavioural.R')    # OUTPUT IS IN VARIABLE B

## MUNGE DATA (preprocess, recode, etc.)
source('munge/recode_instruments.R')     # This produces S data frame (Survey)
source('munge/merge_data.R')             # This combines Behavioural & Survey 

## DIAGNOSE data
source('scr/diagnose_simple.R')          # describe the data (N, etc.) 
source('scr/diagnostic_plots.R')         # display histograms

## ANALYSIS
source('scr/linear_models.R')            # simple regression and ANOVA examples
source('scr/categorical_models.R')       # predict groupings

## OUTPUTS
source('scr/figure1.R',print.eval=TRUE)  # create Figure 1 for manuscript
source('scr/table1.R')                   # create Table 1 for manuscript (descriptives)
