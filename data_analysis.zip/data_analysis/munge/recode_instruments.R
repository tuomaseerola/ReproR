#############################
# recode_instruments.R
# TE 2014-09-12
#
#############################

## Reorganise measures and provide reliability estimates

# empathy
#cat("Empathy...\n")

v$IRS_3 <- 6-v$IRS_3      # reverse-coded
v$IRS_4 <- 6-v$IRS_4      # reverse-coded
v$IRS_7 <- 6-v$IRS_7      # reverse-coded
v$IRS_12 <- 6-v$IRS_12      # reverse-coded
v$IRS_13 <- 6-v$IRS_13      # reverse-coded
v$IRS_14 <- 6-v$IRS_14      # reverse-coded
v$IRS_15 <- 6-v$IRS_15      # reverse-coded
v$IRS_18 <- 6-v$IRS_18      # reverse-coded
v$IRS_19 <- 6-v$IRS_19      # reverse-coded

V <- data.frame(v)

# calculate sub-components
# also do some imputation of MISSING values with individual construct means
impute.mean <- function(x) replace(x, is.na(x), rowMeans(x, na.rm = TRUE)) # MEANS FOR ROWS, PROBABLY CLOSE TO TRUE

### FANTASY
tmp<-V[,c(which(names(V)=="IRS_26"),which(names(V)=="IRS_5"),which(names(V)=="IRS_7"),which(names(V)=="IRS_16"),which(names(V)=="IRS_1"),which(names(V)=="IRS_12"),which(names(V)=="IRS_23"))]

l<-dim(tmp)
	for(i in 1:l[1])
{
	tmp[i,]<-round(impute.mean(tmp[i,]))	
}
a_value <- alpha(tmp,check.keys=FALSE)
#print(a_value$total$raw_alpha)
cat("IRS - fantasy - alpha =",a_value$total$raw_alpha,"\n")

V$IRS_fantasy <- rowSums(tmp)

##### PERSPECTIVE TAKING

tmp<-V[,c(which(names(V)=="IRS_28"),which(names(V)=="IRS_15"),which(names(V)=="IRS_11"),which(names(V)=="IRS_21"),which(names(V)=="IRS_3"),which(names(V)=="IRS_8"),which(names(V)=="IRS_25"))]

l<-dim(tmp)
	for(i in 1:l[1])
{
	tmp[i,]<-round(impute.mean(tmp[i,]))	
}
a_value <- alpha(tmp,check.keys=FALSE)
#print(a_value$total$raw_alpha)
cat("IRS - perspective - alpha =",a_value$total$raw_alpha,"\n")

V$IRS_perspective <- rowSums(tmp)

##### CONCERN

tmp<-V[,c(which(names(V)=="IRS_9"),which(names(V)=="IRS_18"),which(names(V)=="IRS_2"),which(names(V)=="IRS_22"),which(names(V)=="IRS_4"),which(names(V)=="IRS_14"),which(names(V)=="IRS_20"))]

l<-dim(tmp)
	for(i in 1:l[1])
{
	tmp[i,]<-round(impute.mean(tmp[i,]))	
}
a_value <- alpha(tmp,check.keys=FALSE)
#print(a_value$total$raw_alpha)
cat("IRS - concern - alpha =",a_value$total$raw_alpha,"\n")

V$IRS_concern <- rowSums(tmp)

##### DISTRESS

tmp<-V[,c(which(names(V)=="IRS_27"),which(names(V)=="IRS_10"),which(names(V)=="IRS_6"),which(names(V)=="IRS_19"),which(names(V)=="IRS_17"),which(names(V)=="IRS_13"),which(names(V)=="IRS_24"))]

l<-dim(tmp)
	for(i in 1:l[1])
{
	tmp[i,]<-round(impute.mean(tmp[i,]))	
}
a_value <- alpha(tmp,check.keys=FALSE)
#print(a_value$total$raw_alpha)
cat("IRS - distress - alpha =",a_value$total$raw_alpha,"\n")

V$IRS_distress <- rowSums(tmp)

tmp<-V[,52:79]

l<-dim(tmp)
	for(i in 1:l[1])
{
	tmp[i,]<-round(impute.mean(tmp[i,]))	
}

V$IRS_empathy <- rowSums(tmp)

####################################################
## GHQ12
#cat("GHQ...\n")

which(names(V)=="GHQ_1")
which(names(V)=="GHQ_12")

tmp<-V[,20:31]

tmp[tmp==1]<-0      # reverse-coded
tmp[tmp==2]<-1      # reverse-coded
tmp[tmp==3]<-1      # reverse-coded

a_value <- alpha(tmp,check.keys=FALSE)
#print(a_value$total$raw_alpha)
cat("GHQ - alpha =",a_value$total$raw_alpha,"\n")

V$GHQ<-rowSums(tmp)

##################################################
#cat("Contagion...\n")

tmp<-V[,which(names(V)=="Doherty_1"):which(names(V)=="Doherty_15")]

l<-dim(tmp)
	for(i in 1:l[1])
{
	tmp[i,]<-round(impute.mean(tmp[i,]))	
}

a_value <- alpha(tmp,check.keys=FALSE)
#print(a_value$total$raw_alpha)
cat("Emotion contagion - alpha =",a_value$total$raw_alpha,"\n")


V$EC<-rowSums(tmp)

##################################################
#cat("Southampton...\n")

tmp<-V[,which(names(V)=="Southampton_1"):which(names(V)=="Southampton_5")]

a_value <- alpha(tmp,check.keys=FALSE)
#print(a_value$total$raw_alpha)
cat("Southampton Nostalgia Scale - alpha =",a_value$total$raw_alpha,"\n")

V$SNS<-rowSums(tmp)

##################################################

#cat("Absorption...\n")

tmp<-V[,which(names(V)=="AIT_1"):which(names(V)=="AIT_12")]

a_value <- alpha(tmp,check.keys=FALSE)
#print(a_value$total$raw_alpha)
cat("Absorption - alpha =",a_value$total$raw_alpha,"\n")

V$AB<-rowSums(tmp)

##################################################
# LSMS
#cat("LSMS...\n")

V$GalidoSchubert_2 <- 6-V$GalidoSchubert_2      # reverse-coded
V$GalidoSchubert_4 <- 6-V$GalidoSchubert_4      # reverse-coded
V$GalidoSchubert_6 <- 6-V$GalidoSchubert_6      # reverse-coded
V$GalidoSchubert_9 <- 6-V$GalidoSchubert_9      # reverse-coded

tmp<-V[,which(names(V)=="GalidoSchubert_1"):which(names(V)=="GalidoSchubert_11")]

a_value <- alpha(tmp,check.keys=FALSE)
cat("LSMS - alpha =",a_value$total$raw_alpha,"\n")

V$LSMS<-rowSums(tmp)

#####################################################
# ATTITUDES TOWARDS SAD MUSIC (Peltola Eerola)
#cat("ASM...\n")

tmp<-V[,c(which(names(V)=="PeltolaEerola_13"),which(names(V)=="PeltolaEerola_14"),which(names(V)=="PeltolaEerola_15"),which(names(V)=="PeltolaEerola_16"),which(names(V)=="PeltolaEerola_26"))]

l<-dim(tmp)
	for(i in 1:l[1])
{
	tmp[i,]<-round(impute.mean(tmp[i,]))	
}

a_value <- alpha(tmp,check.keys=FALSE)
cat("ASM - avoidance - alpha =",a_value$total$raw_alpha,"\n")

V$ASM_avoidance<-rowSums(tmp)

# aut

tmp<-V[,c(which(names(V)=="PeltolaEerola_1"),which(names(V)=="PeltolaEerola_22"),which(names(V)=="PeltolaEerola_25"),which(names(V)=="PeltolaEerola_28"),which(names(V)=="PeltolaEerola_29"))]

l<-dim(tmp)
	for(i in 1:l[1])
{
	tmp[i,]<-round(impute.mean(tmp[i,]))	
}

a_value <- alpha(tmp,check.keys=FALSE)
cat("ASM - autobiographical - alpha =",a_value$total$raw_alpha,"\n")

V$ASM_autobiographical <- rowSums(tmp) # check whether some items need to be reversed

# Revival

tmp<-V[,c(which(names(V)=="PeltolaEerola_2"),which(names(V)=="PeltolaEerola_3"),which(names(V)=="PeltolaEerola_12"),which(names(V)=="PeltolaEerola_24"),which(names(V)=="PeltolaEerola_27"))]

l<-dim(tmp)
	for(i in 1:l[1])
{
	tmp[i,]<-round(impute.mean(tmp[i,]))	
}

a_value <- alpha(tmp,check.keys=FALSE)
cat("ASM - revival - alpha =",a_value$total$raw_alpha,"\n")

V$ASM_revival <- rowSums(tmp) # check whether some items need to be reversed

# Approach

tmp<-V[,c(which(names(V)=="PeltolaEerola_5"),which(names(V)=="PeltolaEerola_19"),which(names(V)=="PeltolaEerola_20"),which(names(V)=="PeltolaEerola_21"))]

l<-dim(tmp)
	for(i in 1:l[1])
{
	tmp[i,]<-round(impute.mean(tmp[i,]))	
}

a_value <- alpha(tmp,check.keys=FALSE)
cat("ASM - appreciation - alpha =",a_value$total$raw_alpha,"\n")

V$ASM_appreciation <- rowSums(tmp) # check whether some items need to be reversed

# Int

tmp<-V[,c(which(names(V)=="PeltolaEerola_8"),which(names(V)=="PeltolaEerola_9"),which(names(V)=="PeltolaEerola_10"))]

# round(colMeans(tmp,na.rm=TRUE))
tmp[8,]<-c(4,3,3) # interpolate the missing values from the group means

l<-dim(tmp)
	for(i in 1:l[1])
{
	tmp[i,]<-round(impute.mean(tmp[i,]))	
}

a_value <- alpha(tmp,check.keys=FALSE)
cat("ASM - intersubjective - alpha =",a_value$total$raw_alpha,"\n")

V$ASM_intersubjective <- rowSums(tmp) # check whether some items need to be reversed

# Amplify

tmp<-V[,c(which(names(V)=="PeltolaEerola_4"),which(names(V)=="PeltolaEerola_17"),which(names(V)=="PeltolaEerola_18"))]

l<-dim(tmp)
	for(i in 1:l[1])
{
	tmp[i,]<-round(impute.mean(tmp[i,]))	
}

a_value <- alpha(tmp,check.keys=FALSE)
cat("ASM - amplification - alpha =",a_value$total$raw_alpha,"\n")

V$ASM_amplification <- rowSums(tmp) # check whether some items need to be reversed


ID<-seq(1,42) #ID 
names(ID)<-"ID"
V$ID<-ID

## Choose the Relevant data and put them into a variable
S <- V[,c("ID","Sukupuoli","Ika","Siviilisaaty","Koulutus","Tyo","Ruumiillinen.kunto","Terveydentila","Elamanlaatu","Muusikkous","IRS_fantasy","IRS_perspective","IRS_concern","IRS_distress","IRS_empathy","GHQ","EC","SNS","AB","LSMS","ASM_avoidance","ASM_autobiographical","ASM_revival","ASM_appreciation","ASM_intersubjective","ASM_amplification")]

# relabel some remaining Finnish column names into English

colnames(S)[colnames(S)=="Sukupuoli"]<-"Gender"
colnames(S)[colnames(S)=="Ika"]<-"Age"
colnames(S)[colnames(S)=="Siviilisaaty"]<-"SocialStatus"
colnames(S)[colnames(S)=="Tyo"]<-"Employment"
colnames(S)[colnames(S)=="Ruumiillinen.kunto"]<-"PhysicalHealth"
colnames(S)[colnames(S)=="Terveydentila"]<-"OverallHealth"
colnames(S)[colnames(S)=="Elamanlaatu"]<-"QualityOfLife"
colnames(S)[colnames(S)=="Muusikkous"]<-"Musician"
colnames(S)[colnames(S)=="Koulutus"]<-"Education"

rm(ID,V,tmp,v,a_value,i,l)
rm(impute.mean)