# merge_data.R

## Choose the Relevant data and Export them

CD1 <- S[,c("ID","Gender","Age","SocialStatus","Education","Employment","PhysicalHealth","OverallHealth","QualityOfLife","Musician","IRS_fantasy","IRS_perspective","IRS_concern","IRS_distress","IRS_empathy","GHQ","EC","SNS","AB","LSMS","ASM_avoidance","ASM_autobiographical","ASM_revival","ASM_appreciation","ASM_intersubjective","ASM_amplification")]
CD2 <- B[,c("ID","felt.anxious","felt.intensity","felt.moved","felt.peaceful","felt.sad","liking","perceived.negative","perceived.peaceful","perceived.positive","perceived.sad","perceived.scary")]

df <- merge(CD1,CD2,by="ID") # combine

rm(CD1,CD2)